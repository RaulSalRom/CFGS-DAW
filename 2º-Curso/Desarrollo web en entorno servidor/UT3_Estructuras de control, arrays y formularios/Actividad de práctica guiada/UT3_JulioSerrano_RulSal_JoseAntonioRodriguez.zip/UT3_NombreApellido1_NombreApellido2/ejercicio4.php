<?php
/*
 * Ejercicio 4: formulario y procesamiento seguro en un solo fichero
 * Conductor: integrante B
 * Navegante: integrante A
 */

// Variables para conservar los datos y mostrar resultados
$nombre = "";
$nota1 = "";
$nota2 = "";
$errores = [];
$resultado = "";

// Comprobamos si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recuperación de los campos con filter_input (sin acceder a $_POST)
    $nombre = trim((string) filter_input(INPUT_POST, "nombre"));
    $nota1 = trim((string) filter_input(INPUT_POST, "nota1"));
    $nota2 = trim((string) filter_input(INPUT_POST, "nota2"));

    // Validaciones
    if ($nombre === "" || $nota1 === "" || $nota2 === "") {
        $errores[] = "Todos los campos son obligatorios.";
    } else {
        if (!is_numeric($nota1) || !is_numeric($nota2)) {
            $errores[] = "Las notas deben ser numéricas.";
        } elseif ($nota1 < 0 || $nota1 > 10 || $nota2 < 0 || $nota2 > 10) {
            $errores[] = "Las notas deben estar comprendidas entre 0 y 10.";
        }
    }

    // Si todo es correcto, calculamos la media y la calificación
    if (empty($errores)) {
        $media = ($nota1 + $nota2) / 2;

        if ($media < 5) {
            $calificacion = "suspenso";
        } elseif ($media < 7) {
            $calificacion = "aprobado";
        } elseif ($media < 9) {
            $calificacion = "notable";
        } else {
            $calificacion = "sobresaliente";
        }

        $resultado = "Alumno: " . htmlspecialchars($nombre) .
            " | Nota media: " . $media .
            " | Calificación: " . $calificacion;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cálculo de nota media</title>
</head>
<body>

<?php
// Mensajes de error en rojo
foreach ($errores as $error) {
    echo "<p style='color:red;'>" . $error . "</p>";
}
// Resultado correcto
if ($resultado !== "") {
    echo "<p>" . $resultado . "</p>";
}
?>

<h1>Cálculo de nota media</h1>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <p>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>">
    </p>
    <p>
        <label for="nota1">Nota 1:</label>
        <input type="text" id="nota1" name="nota1" value="<?php echo htmlspecialchars($nota1); ?>">
    </p>
    <p>
        <label for="nota2">Nota 2:</label>
        <input type="text" id="nota2" name="nota2" value="<?php echo htmlspecialchars($nota2); ?>">
    </p>
    <input type="submit" value="Calcular">
</form>

</body>
</html>
