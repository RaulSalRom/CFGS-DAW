<?php
/*
 * Librería de funciones (Ejercicio 2)
 * Conductor: integrante B
 * Navegante: integrante A
 */

// Aplica un descuento (por defecto 10 %) a cada precio, modificando el array original
function aplicarDescuento(&$precios, $porcentaje = 10)
{
    // &$precio permite modificar los valores reales del array
    foreach ($precios as &$precio) {
        $precio = $precio - ($precio * $porcentaje / 100);
    }
    unset($precio); // buena práctica: romper la referencia
}

// Devuelve el importe incrementado un 21 %
function calcularIvaGeneral($importe)
{
    return $importe * 1.21;
}

// Devuelve el importe incrementado un 10 %
function calcularIvaReducido($importe)
{
    return $importe * 1.10;
}

// Recibe el nombre de una función (callback) y la ejecuta sobre el importe
function procesarFactura($funcionIva, $importe)
{
    return $funcionIva($importe);
}
