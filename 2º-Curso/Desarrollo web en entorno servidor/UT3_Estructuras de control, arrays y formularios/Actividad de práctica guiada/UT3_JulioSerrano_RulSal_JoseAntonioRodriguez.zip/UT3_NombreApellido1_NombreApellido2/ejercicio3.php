<?php
/*
 * Ejercicio 3: control de excepciones (try / catch / finally)
 * Conductor: integrante A
 * Navegante: integrante B
 */

// Valida la edad; lanza excepciones si no es válida
function validarEdadRegistro($edad)
{
    // Vacío o no numérico
    if (empty($edad) || !is_numeric($edad)) {
        throw new Exception("Error: el dato introducido no es un valor numérico válido.");
    }
    // Menor de edad
    if ($edad < 18) {
        throw new Exception("Error: debes ser mayor de edad para completar el registro.");
    }
    return true;
}

// Escenarios de prueba
$casosPrueba = [25, 15, "abc", "", 40];

foreach ($casosPrueba as $edad) {
    try {
        validarEdadRegistro($edad);
        echo "<p>Edad $edad válida: registro permitido.</p>";
    } catch (Exception $e) {
        // Se muestra el mensaje de la excepción
        echo "<p>" . $e->getMessage() . "</p>";
    } finally {
        // Se ejecuta siempre
        echo "<p>--- Comprobación finalizada ---</p>";
    }
}
