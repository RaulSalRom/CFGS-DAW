<?php
/*
 * Ejercicio 1: condicionales, bucles y operadores de arrays
 * Conductor: integrante A
 * Navegante: integrante B
 */

// 1. Arrays asociativos de inventario (clave = código, valor = unidades).
// P01 está en ambos con distinta cantidad; el resto de códigos son distintos.
$almacen1 = ["P01" => 10, "P02" => 0, "P03" => 3, "P04" => 20];
$almacen2 = ["P01" => 25, "P05" => 8, "P06" => 0, "P07" => 15];

// 2. Comparación con == (igual) y === (idéntico)
echo "<h2>Comparación de almacenes</h2>";
if ($almacen1 == $almacen2) {
    echo "<p>Los almacenes son iguales (==).</p>";
} else {
    echo "<p>Los almacenes NO son iguales (==).</p>";
}
if ($almacen1 === $almacen2) {
    echo "<p>Los almacenes son idénticos (===).</p>";
} else {
    echo "<p>Los almacenes NO son idénticos (===).</p>";
}

// 3. Unión de arrays con el operador +
// (si una clave existe en ambos, se conserva el valor del primer array)
$stockTotal = $almacen1 + $almacen2;
echo "<h2>Stock total</h2>";
echo "<pre>";
print_r($stockTotal);
echo "</pre>";

// 4. Recorrido del stock total
echo "<h2>Estado de los productos</h2>";
foreach ($stockTotal as $codigo => $unidades) {
    // Si no hay unidades, se salta la iteración
    if ($unidades == 0) {
        continue;
    }

    // Estado según las unidades
    if ($unidades < 5) {
        $estado = "Stock crítico (reponer urgente)";
    } elseif ($unidades <= 15) {
        $estado = "Stock normal";
    } else {
        $estado = "Exceso de stock";
    }

    echo "<p>Producto $codigo: $unidades unidades → $estado</p>";
}
