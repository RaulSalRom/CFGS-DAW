<?php
/*
 * Ejercicio 2: librería de funciones, paso por referencia y callbacks
 * Conductor: integrante B
 * Navegante: integrante A
 */

// Enlazamos la librería
require_once "libreria.php";

// Array indexado con 5 precios iniciales
$precios = [100, 250, 50, 80, 120];

echo "<h2>Precios originales</h2>";
echo "<pre>";
print_r($precios);
echo "</pre>";

// Descuento con el valor por defecto (10 %), el array se modifica por referencia
aplicarDescuento($precios);

echo "<h2>Precios tras aplicar el descuento (10 %)</h2>";
echo "<pre>";
print_r($precios);
echo "</pre>";

// Callbacks: se pasa el nombre de la función como cadena
$importe = 100;
echo "<h2>Facturas</h2>";
echo "<p>Importe $importe con IVA general (21 %): " . procesarFactura("calcularIvaGeneral", $importe) . " €</p>";
echo "<p>Importe $importe con IVA reducido (10 %): " . procesarFactura("calcularIvaReducido", $importe) . " €</p>";
