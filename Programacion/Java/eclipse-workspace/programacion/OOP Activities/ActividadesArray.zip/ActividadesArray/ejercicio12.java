package ActividadesArray;

import java.util.*;

public class ejercicio12 {

	public static void main(String[]args) {
		//creamos el array
		int[] arrays = {1, 2, 3, 4, 5};
		//lo mostramos por pantalla
		System.out.println(Arrays.toString(arrays));
		//llamamos al metodo
		multiplicarPorDos(arrays);
		//mostramos el resultado por pantalla
		System.out.println(Arrays.toString(arrays));
	}
	public static void multiplicarPorDos(int[] arrays) {
		//vemos que no modificamos los valores del array pq el for each no puede hacerlo
		for(int i  : arrays) {
			
			i *= 2;
			
		}
	}
}
